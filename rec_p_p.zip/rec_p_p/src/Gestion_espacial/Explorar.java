package Gestion_espacial;

public interface Explorar {

    boolean explorar();
}
