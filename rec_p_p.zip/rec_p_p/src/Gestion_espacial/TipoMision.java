package Gestion_espacial;

public enum TipoMision {

    CARTOGRAFIA,
    INVESTIGACION,
    CONTACTO,
}
