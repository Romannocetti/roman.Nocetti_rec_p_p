package Gestion_espacial;

import java.util.ArrayList;
import java.util.List;

public class Agencia {
    private String nombre;
    private List<Nave> naves; ;

    public Agencia(String nombre) {
        this.nombre = nombre;
        this.naves = new ArrayList<>();
    }

    

    public void agregarNave(Nave nave){
        verificarNave(nave);
        naves.add(nave);
 
    }
    
    private void verificarNave(Nave nave) {
        
        if (naves.contains(nave)) {
            throw new YaExiste();     
        }
        
        if(naves == null) {
            throw new NullPointerException();
        }
    }
    
    public void mostrarNaves() {
        for(Nave a : naves) {     
            System.out.println(a);
        }
      
    }
        
    public void iniarExploracion() {
        for(Nave n : naves) {
            if(n instanceof Explorar explorar && explorar.explorar()){

                System.out.println("Una nave salio a explorar:\n" + n + "\n");
            } else
            {
                System.out.println("Una nave no tiene la capacidad de salir a explorar:\n" + n + "\n");
            }
                
        }
    }
    
}
