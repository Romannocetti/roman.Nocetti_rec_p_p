package Gestion_espacial;

public class YaExiste extends RuntimeException{
    
    private static final String MESSAGE = "Ya se encuentra esa nave en la agencia estelar.";

    public YaExiste() {
        super(MESSAGE);
    }
    
    
    
    
}
