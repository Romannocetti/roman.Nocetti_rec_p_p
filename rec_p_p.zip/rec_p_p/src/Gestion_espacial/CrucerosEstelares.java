package Gestion_espacial;

public class CrucerosEstelares extends Nave {
      
    private int cantidadTribulacion;

    public CrucerosEstelares(String nombre, int capacidadPasajeros, int anoLanzamiento, int cantidadTribulacion) {
        super(nombre, capacidadPasajeros, anoLanzamiento);
        verificarPasajeros(cantidadTribulacion);
        this.cantidadTribulacion = cantidadTribulacion;
    }

        private void verificarPasajeros(int cantidadTribulacion) {
        if (cantidadTribulacion > getCapacidadPasajeros() ) {
            throw new IllegalArgumentException();
        }
    }

    @Override
    public String toString() {
        return "CrucerosEstelares{" + "nombre = " + getNombre() +  " cantidadTribulacion = " + cantidadTribulacion +", capacidadPasajeros = " + getCapacidadPasajeros() + ", anoLanzamiento = " + getAnoLanzamiento() + '}';
    }
        
        
    
}
