package Gestion_espacial;

import java.util.List;
import java.util.Objects;

public abstract class Nave {
    private String nombre;
    private int capacidadPasajeros;
    private int anoLanzamiento;

    public Nave(String nombre, int capacidadPasajeros, int anoLanzamiento) {
        this.nombre = nombre;
        this.capacidadPasajeros = capacidadPasajeros;
        this.anoLanzamiento = anoLanzamiento;
    }

    public int getCapacidadPasajeros() {
        return capacidadPasajeros;
    }

    public String getNombre() {
        return nombre;
    }

    public int getAnoLanzamiento() {
        return anoLanzamiento;
    }

    
    @Override
    public String toString() {
        return "Nave{" + " nombre = " + nombre + ", capacidadPasajeros = " + capacidadPasajeros + ", anoLanzamiento = " + anoLanzamiento + '}';
    }
    
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        
        if(obj instanceof Nave n) {
            return (n.anoLanzamiento == anoLanzamiento && n.nombre.equals(nombre));
        }
       
        return false;
     
    }
    


    @Override
    public int hashCode() {
        return Objects.hash(anoLanzamiento, nombre);
    }
    
    
}
