package Gestion_espacial;

public class NavesDeExploracion extends Nave implements Explorar{
    
    private TipoMision mision;
    private boolean apto;

    public NavesDeExploracion(String nombre, int capacidadPasajeros, int anoLanzamiento,TipoMision mision, boolean apto) {
        super(nombre, capacidadPasajeros, anoLanzamiento);
        this.apto = apto;
        this.mision = mision;
    }

    public TipoMision getMision() {
        return mision;
    }

    
    @Override
    public String toString() {
        return "NavesDeExploracion{" + "nombre = " + getNombre() + ", capacidadPasajeros = " + getCapacidadPasajeros() + ", anoLanzamiento = " + getAnoLanzamiento() + " tipo de mision = " + getMision() + '}';
    }




    @Override
    public boolean explorar() {
        if (apto == false) {    
            this.apto = true;
            return true;
        }
        
        return false;
    }
}

