package Gestion_espacial;

public class Cargueros extends Nave implements Explorar {
    
    private boolean apto;
    private int carga;

    public Cargueros(String nombre, int capacidadPasajeros, int anoLanzamiento, int carga, boolean apto) {
        super(nombre, capacidadPasajeros, anoLanzamiento);
        verificarCarga(carga);
        this.apto = apto;
        this.carga = carga;
    }

    private void verificarCarga(int carga) {
        if (carga < 100 || carga > 500 ) {
            throw new IllegalArgumentException();
        }
    }
    
    
    @Override
    public boolean explorar() {
                if (apto == false) {    
            this.apto = true;
            return true;
        }
        
        return false;
    }

    @Override
    public String toString() {
        return "Cargueros{" + "nombre = " + getNombre() + ", carga = " + carga  +", capacidadPasajeros = " + getCapacidadPasajeros() + ", anoLanzamiento = " + getAnoLanzamiento() +'}';
    }

    
}
