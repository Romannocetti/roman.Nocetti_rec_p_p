
package Gestion_espacial;


public class Main {

  
    public static void main(String[] args) {
        
        Agencia agen = new Agencia("inter estelar");
        
        cargarAgencia(agen);
        agen.iniarExploracion();
        agen.mostrarNaves();
    }
    
    public static void cargarAgencia(Agencia agen) {
        
        
        try {
        
        CrucerosEstelares c1 = new CrucerosEstelares("pepaerrante", 300, 2022, 200);
        
        NavesDeExploracion e1 = new NavesDeExploracion("popelle", 300, 200, TipoMision.CONTACTO, false );
        
        
        Cargueros car1 = new Cargueros("Galactica", 100, 2025, 300, false );
        Cargueros car2 = new Cargueros("Galactica", 100, 2025, 300, false);
        Cargueros car3 = new Cargueros("pepe", 50, 2025, 300, false);

        agen.agregarNave(e1);   
        agen.agregarNave(c1);
        agen.agregarNave(car1);
        agen.agregarNave(car3);
        agen.agregarNave(car2);
        


        }
        catch (YaExiste | NullPointerException ex){
            System.out.println("Ha ocurrido un error: " + ex.getMessage());
        } 
        catch (IllegalArgumentException ex) {
            System.out.println("Se ha ingresado un valor inválido en los datos de las naves");
        }
    
        
        
       
       
    }
    
}
